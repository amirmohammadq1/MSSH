package ir.shonud.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
